# Zora Tip Jar

A Farcaster Frame for tipping creators with Zora coin in one click.

## Status

Early stage. UI concept done, Frame logic in progress.
